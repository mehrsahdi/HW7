//مهرسا احمدی 40223002
#include <stdio.h>
#include <string.h>
#include <ctype.h>

struct language 
{
    char word1[100];
    char word2[100];
};

int main()
{
    int n, b=0, c=0;

    printf("Enter the number of words of each laguage : ");
    scanf("%d",&n);
    struct language word[n];

    printf("Enter the first word and it's equivalent with one space between them in each line");
    printf("( all the letters should be small )\n");
    for(int i=0 ; i<n ; i++)
    {
        printf("line %d :", i + 1 );
        scanf("%s %s",word[i].word1,word[i].word2);
    }

    char sentence[100];
    printf("Enter a sentence with the words of language 1");
    printf("(The first words you've entered for each line) : \n");
    getchar();
    gets(sentence);
    char space=' ';
    char null='\0';

    char str[50][50];
    int l=strlen(sentence);
    for ( int i=0 ; i<l ; i++)
    {
        if ( sentence[i] == space || sentence[i] == null)
        {
            str[b][c]='\0';
            b++;
            c=0;
        }

        else
        {
            str[b][c]=tolower(sentence[i]);
            c++;
        }
    }

    
    for (int i=0 ; i<=b ; i++)
    {
        for ( int j=0 ; j<n ; j++ )
        {
            if ( strcmp(str[i],word[j].word1)==0 || strcmp(str[i],word[j].word2)==0)
            {
                if( strlen ( str[i] ) <= strlen ( word[j].word2 ))
                printf("%s ",word[j].word1);

                else
                printf("%s ",word[j].word2);
            }
        }
    }




    return 0;
}